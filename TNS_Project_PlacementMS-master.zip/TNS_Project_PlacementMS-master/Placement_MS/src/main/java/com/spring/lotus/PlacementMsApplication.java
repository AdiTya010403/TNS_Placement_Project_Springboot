package com.spring.lotus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementMsApplication.class, args);
	}

}
