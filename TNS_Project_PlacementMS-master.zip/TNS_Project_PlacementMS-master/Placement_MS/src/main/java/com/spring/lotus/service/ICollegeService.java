package com.spring.lotus.service;

import java.util.List;

import com.spring.lotus.entity.College;

public interface ICollegeService {

	List<College> getAllColleges();
	College getCollegeById(Long id);
	void addCollege(College c);
	void deleteCollege(Long id);
	void updateCollege(Long id, College c);
}
